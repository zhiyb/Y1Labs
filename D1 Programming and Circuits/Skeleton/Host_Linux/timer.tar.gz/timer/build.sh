#!/bin/sh
gcc main.c timer.c -Wall -s -o2 -o test_timer
